# Billing System - Bhumi Polymers

A GST billing system built with React. Features:
- Create and print Tax Invoices
- Add Customers
- View Invoice Ledger

## Live Demo
[https://anuja-git-code.github.io/Billing-system](https://anuja-git-code.github.io/Billing-system)

## Deploy to GitHub Pages

```bash
cd frontend
npm install
npm run deploy
```
