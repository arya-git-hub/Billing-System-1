// ✅ Backend API URL
// After deploying backend to Render, replace this with your Render URL
// e.g. https://billing-backend-xxxx.onrender.com
const API_URL = process.env.REACT_APP_API_URL || "https://billing-backend-bhumi.onrender.com";

export default API_URL;
