import { useState, useEffect } from "react";
import API_URL from "../config";

function Ledger() {
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch(`${API_URL}/invoices`)
      .then(res => {
        if (!res.ok) throw new Error("Server error: " + res.status);
        return res.json();
      })
      .then(data => {
        setInvoices(Array.isArray(data) ? data : []);
        setLoading(false);
      })
      .catch(err => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  if (loading) return (
    <div style={{ padding: "40px", textAlign: "center" }}>
      <div style={{ fontSize: "18px", color: "#666" }}>Loading invoices...</div>
    </div>
  );

  if (error) return (
    <div style={{ padding: "40px", textAlign: "center" }}>
      <div style={{ fontSize: "18px", color: "red" }}>⚠️ Could not load invoices</div>
      <div style={{ fontSize: "14px", color: "#666", marginTop: "8px" }}>{error}</div>
      <div style={{ fontSize: "13px", color: "#999", marginTop: "8px" }}>Make sure the backend server is running</div>
    </div>
  );

  if (invoices.length === 0) return (
    <div style={{ padding: "40px", textAlign: "center" }}>
      <div style={{ fontSize: "18px", color: "#666" }}>No invoices found.</div>
      <div style={{ fontSize: "14px", color: "#999", marginTop: "8px" }}>Save an invoice first from the New Invoice tab</div>
    </div>
  );

  return (
    <div style={{ padding: "20px", fontFamily: "'Inter', sans-serif" }}>
      <h2 style={{ marginBottom: "20px" }}>Invoice Ledger ({invoices.length} invoices)</h2>

      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ background: "#1a1a2e", color: "white" }}>
            <th style={th}>Date</th>
            <th style={th}>Customer</th>
            <th style={th}>Items</th>
            <th style={th}>Subtotal</th>
            <th style={th}>SGST</th>
            <th style={th}>CGST</th>
            <th style={th}>Grand Total</th>
          </tr>
        </thead>
        <tbody>
          {invoices.map((inv, i) => (
            <tr key={inv._id || i} style={{ background: i % 2 === 0 ? "#fff" : "#f9f9f9" }}>
              <td style={td}>{new Date(inv.date || inv.createdAt).toLocaleDateString("en-IN")}</td>
              <td style={td}>
                <strong>{inv.customer?.name || "N/A"}</strong>
                {inv.customer?.address && <div style={{ fontSize: "12px", color: "#666" }}>{inv.customer.address}</div>}
              </td>
              <td style={td}>
                <ul style={{ margin: 0, paddingLeft: "16px", fontSize: "12px" }}>
                  {(inv.items || []).map((item, j) => (
                    <li key={j}>{item.qty}x {item.desc} — ₹{item.total}</li>
                  ))}
                </ul>
              </td>
              <td style={{ ...td, textAlign: "right" }}>₹{Number(inv.totals?.total || 0).toFixed(2)}</td>
              <td style={{ ...td, textAlign: "right" }}>₹{Number(inv.totals?.sgst || 0).toFixed(2)}</td>
              <td style={{ ...td, textAlign: "right" }}>₹{Number(inv.totals?.cgst || 0).toFixed(2)}</td>
              <td style={{ ...td, textAlign: "right", fontWeight: "bold", color: "#1a1a2e" }}>₹{Number(inv.totals?.grand || 0).toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr style={{ background: "#f2f0ff", fontWeight: "bold" }}>
            <td style={td} colSpan={3}>Total</td>
            <td style={{ ...td, textAlign: "right" }}>₹{invoices.reduce((s, i) => s + Number(i.totals?.total || 0), 0).toFixed(2)}</td>
            <td style={{ ...td, textAlign: "right" }}>₹{invoices.reduce((s, i) => s + Number(i.totals?.sgst || 0), 0).toFixed(2)}</td>
            <td style={{ ...td, textAlign: "right" }}>₹{invoices.reduce((s, i) => s + Number(i.totals?.cgst || 0), 0).toFixed(2)}</td>
            <td style={{ ...td, textAlign: "right", color: "#5c4dff" }}>₹{invoices.reduce((s, i) => s + Number(i.totals?.grand || 0), 0).toFixed(2)}</td>
          </tr>
        </tfoot>
      </table>
    </div>
  );
}

const th = { padding: "10px 14px", textAlign: "left", fontWeight: "600", fontSize: "13px" };
const td = { padding: "10px 14px", border: "1px solid #eee", fontSize: "13px", verticalAlign: "top" };

export default Ledger;
