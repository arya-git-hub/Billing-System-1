import { useState, useEffect } from "react";
import API_URL from "../config";

function Customers() {
  const [form, setForm] = useState({ name: "", address: "", gst: "", phone: "" });
  const [customers, setCustomers] = useState([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch(`${API_URL}/customers`)
      .then(res => res.json())
      .then(data => setCustomers(Array.isArray(data) ? data : []))
      .catch(err => console.error("Failed to load customers:", err));
  }, []);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async () => {
    if (!form.name) { alert("Customer name is required"); return; }
    setSaving(true);
    try {
      const response = await fetch(`${API_URL}/save-customer`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const data = await response.json();
      if (response.ok) {
        alert("Customer saved successfully! ✅");
        setCustomers([data.customer, ...customers]);
        setForm({ name: "", address: "", gst: "", phone: "" });
      } else {
        alert("Failed: " + (data.error || "Unknown error"));
      }
    } catch (error) {
      alert("Error: Could not connect to server. " + error.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div style={{ padding: "20px", maxWidth: "800px" }}>
      <h2>Add Customer</h2>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px", marginBottom: "16px" }}>
        <div>
          <label style={{ display: "block", marginBottom: "4px", fontWeight: "bold" }}>Name *</label>
          <input type="text" name="name" value={form.name} placeholder="Customer Name" onChange={handleChange} style={{ width: "100%", padding: "8px", border: "1px solid #ccc", borderRadius: "4px" }} />
        </div>
        <div>
          <label style={{ display: "block", marginBottom: "4px", fontWeight: "bold" }}>Phone</label>
          <input type="text" name="phone" value={form.phone} placeholder="Phone Number" onChange={handleChange} style={{ width: "100%", padding: "8px", border: "1px solid #ccc", borderRadius: "4px" }} />
        </div>
        <div>
          <label style={{ display: "block", marginBottom: "4px", fontWeight: "bold" }}>GST Number</label>
          <input type="text" name="gst" value={form.gst} placeholder="GST Number" onChange={handleChange} style={{ width: "100%", padding: "8px", border: "1px solid #ccc", borderRadius: "4px" }} />
        </div>
        <div>
          <label style={{ display: "block", marginBottom: "4px", fontWeight: "bold" }}>Address</label>
          <input type="text" name="address" value={form.address} placeholder="Address" onChange={handleChange} style={{ width: "100%", padding: "8px", border: "1px solid #ccc", borderRadius: "4px" }} />
        </div>
      </div>

      <button onClick={handleSubmit} disabled={saving} style={{ padding: "10px 24px", background: saving ? "#ccc" : "#333", color: "white", border: "none", borderRadius: "4px", cursor: "pointer" }}>
        {saving ? "Saving..." : "Save Customer"}
      </button>

      {customers.length > 0 && (
        <div style={{ marginTop: "30px" }}>
          <h3>Saved Customers ({customers.length})</h3>
          <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "10px" }}>
            <thead>
              <tr style={{ background: "#f2f2f2" }}>
                <th style={{ padding: "8px", border: "1px solid #ddd", textAlign: "left" }}>Name</th>
                <th style={{ padding: "8px", border: "1px solid #ddd", textAlign: "left" }}>Phone</th>
                <th style={{ padding: "8px", border: "1px solid #ddd", textAlign: "left" }}>GST</th>
                <th style={{ padding: "8px", border: "1px solid #ddd", textAlign: "left" }}>Address</th>
              </tr>
            </thead>
            <tbody>
              {customers.map((c, i) => (
                <tr key={c._id || i}>
                  <td style={{ padding: "8px", border: "1px solid #ddd" }}>{c.name}</td>
                  <td style={{ padding: "8px", border: "1px solid #ddd" }}>{c.phone || "—"}</td>
                  <td style={{ padding: "8px", border: "1px solid #ddd" }}>{c.gst || "—"}</td>
                  <td style={{ padding: "8px", border: "1px solid #ddd" }}>{c.address || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default Customers;
