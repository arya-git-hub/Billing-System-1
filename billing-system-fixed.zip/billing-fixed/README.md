# Billing System — Bhumi Polymers

## Project Structure
```
billing-system/
├── frontend/   ← React app (deploy to Vercel)
└── backend/    ← Express + MongoDB (deploy to Render)
```

## Backend Deploy (Render.com) — FREE
1. Go to https://render.com → New → Web Service
2. Connect your GitHub repo
3. Set Root Directory: `backend`
4. Build Command: `npm install`
5. Start Command: `node server.js`
6. Add Environment Variable:
   - Key: `MONGO_URI`
   - Value: `mongodb+srv://Admin:iK0VVWnOdHaq3QcU@cluster0.kzzxwov.mongodb.net/billing-system?retryWrites=true&w=majority&appName=Cluster0`
7. Deploy → copy the URL (e.g. https://billing-backend-bhumi.onrender.com)

## Frontend Deploy (Vercel)
1. In `frontend/.env`, set:
   REACT_APP_API_URL=https://YOUR-RENDER-URL.onrender.com
2. In Vercel dashboard → your project → Settings → Environment Variables
3. Add: REACT_APP_API_URL = https://YOUR-RENDER-URL.onrender.com
4. Redeploy
